//Importazione vari package 
package immobili;

import java.io.Serializable;

public class Immobile implements Serializable {

	// Variabile statica richiesta da Serializable
	static final long serialVersionUID = 1;

	protected String dataPubblicazione;// Data di pubblicazione dell'annuncio
	protected String zona;// Citta' dove si trova
	protected int superficie;// Superficie espressa in metri quadrati
	protected int anno;// Anno di costruzione
	protected char classeEnergetica;// Classe energetica
	protected int numeroStanze;// Numero di stanze
	protected boolean doppiServizi;// Presenza o meno di doppi servizi
	protected int prezzo;// Prezzo espresso in euro

	// costruttore
	public Immobile(String a, String b, int c, int d, char e, int f, boolean g, int h) {
		dataPubblicazione = a;
		zona = b;
		superficie = c;
		anno = d;
		classeEnergetica = e;
		numeroStanze = f;
		doppiServizi = g;
		prezzo = h;
	}

	// Stampa tutte le informazioni dell'oggetto correlate da una breve descrizione
	public void Consulta() {
		System.out.println("Data di pubblicazione: " + dataPubblicazione);
		System.out.println("Zona: " + zona);
		System.out.println("Superficie: " + superficie + "mq");
		System.out.println("Anno: " + anno);
		System.out.println("Classe energetica: " + classeEnergetica);
		System.out.println("Numero di stanze: " + numeroStanze);
		System.out.println("Presenza di doppi servizi: " + doppiServizi);
		System.out.println("Prezzo: " + prezzo);

	}

	// metodo toString
	public String toString() {
		return dataPubblicazione + zona + superficie + anno + classeEnergetica + numeroStanze + doppiServizi + prezzo;
	}

}
