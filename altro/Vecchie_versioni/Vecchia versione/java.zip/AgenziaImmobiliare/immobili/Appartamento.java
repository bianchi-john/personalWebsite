//Importazione vari package 
package immobili;

import java.io.Serializable;

public class Appartamento extends Immobile implements Serializable {

	static final long serialVersionUID = 1; // variabile statica richiesta da "Serializable"

	private int piano;// Piano in cui è collocato l'appartamento
	private int numeroPiani;// Numero di piani presenti nell'edificio dove si trova l'appartamento
	private boolean parcheggio;// Presenza o meno di parcheggio
	private boolean riscaldamento;//// Presenza o meno di riscaldamento

	// Costruttore
	public Appartamento(String a, String b, int c, int d, char e, int f, boolean g, int h, int i, int l, boolean m,
			boolean n) {
		super(a, b, c, d, e, f, g, h);
		piano = i;
		numeroPiani = l;
		parcheggio = m;
		riscaldamento = n;
	}

	// Stampa tutte le informazioni dell'oggetto correlate da una breve descrizione,
	// utilizza parte del metodo gia' definito nella classe "immobile"
	public void Consulta() {
		super.Consulta();//con questo costrutto si utilizza parte del metodo "Consulta" definito nella classe "Immobile"
		System.out.println("Siatuata al piano n': " + piano + " di " + numeroPiani);
		System.out.println("Parcheggio " + parcheggio);
		System.out.println("Riscaldamento " + riscaldamento);
		System.out.println("");

	}

	// Metodo toString
	public String toString() {
		return dataPubblicazione + zona + superficie + anno + classeEnergetica + numeroStanze + doppiServizi + prezzo
				+ piano + parcheggio + riscaldamento;
	}

}
