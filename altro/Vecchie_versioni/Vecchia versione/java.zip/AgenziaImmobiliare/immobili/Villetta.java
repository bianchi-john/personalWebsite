//Importazione vari package 
package immobili;

import java.io.Serializable;

public class Villetta extends Immobile implements Serializable {

	// variabile statica richiesta da "Serializable"
	static final long serialVersionUID = 1;

	private int dimensioniGiardino;// Dimensioni del giardino annesso espresse in metri quadrati

	// Costruttore
	public Villetta(String a, String b, int c, int d, char e, int f, boolean g, int h, int i) {
		super(a, b, c, d, e, f, g, h);
		dimensioniGiardino = i;
	}

	// Stampa tutte le informazioni dell'oggetto correlate da una breve descrizione,
	// utilizza parte del metodo gia' definito nella classe "immobile"
	public void Consulta() {
		super.Consulta();//con questo costrutto si utilizza parte del metodo "Consulta" definito nella classe "Immobile"
		System.out.println("Dimensioni giardino: " + dimensioniGiardino);
		System.out.println("");
	}

	// metodo toString
	public String toString() {
		return dataPubblicazione + zona + superficie + anno + classeEnergetica + numeroStanze + doppiServizi + prezzo
				+ dimensioniGiardino;
	}
}
