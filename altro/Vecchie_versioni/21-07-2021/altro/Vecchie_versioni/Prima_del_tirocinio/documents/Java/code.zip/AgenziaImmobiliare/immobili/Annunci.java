//Importazione vari package 
package immobili;

import java.util.Vector;
import java.util.Collections;
import java.util.ArrayList;
import java.io.*;

public class Annunci {

	// un'immobile e’ una collezione di dati riguardanti esso( vettore )
	private Vector<Immobile> immobili;

	// nome del file in cui è salvato il registro
	private String nomefile = "file.dat";

	// costruttore (Di un contenitore di immobili vuoti) ovvero annunci
	public Annunci() {
		immobili = new Vector<Immobile>();
	}

	// inserisce un immobile negli annunci (se non gia’ presente)
	public void Inserisci(Immobile a) {
		if (!Presente(a))
			immobili.add(a);
	}

	// elimina un certo immobile a partire dalla sua posizione negli annunci
	public void Elimina(int a) {
		immobili.remove(a);
	}

	// verifica se un certo immobile e’ presente
	public boolean Presente(Immobile a) {
		return immobili.contains(a);
	}

		// stampa l’elenco degli immobili
		public void Visualizza() {
			System.out.println(immobili);
		}

	// stampa un immobile a partire dal suo indice all'interno del vettore annunci
	public void VisualizzaScelto(int z) {
		System.out.println("");
		((Immobile) immobili.get(z)).Consulta();
	}

	// Stampa l’elenco degli all'interno del vettore annunci organizzati per data
	public void VisualizzaPerData() {
		ArrayList<String> cars = new ArrayList<String>();// Per fare cio' si serve dei un array creato attraverso la
															// classe "Arraylist"
		for (int i = 0; i < immobili.size(); i = i + 1) {
			cars.add(immobili.get(i).dataPubblicazione);
		}
		// Il metodo java.util.Collections.sort () è presente nella classe
		// java.util.Collections.
		// Viene utilizzato per ordinare gli elementi presenti nell'elenco specificato
		// di Collection in ordine crescente
		Collections.sort(cars);
		// Ciclo che scorre il nuovo vettore creato adesso ordinato per data
		for (int i = 0; i < cars.size(); i = i + 1) {
			// Ciclo annidato che scorre all'interno del vettore immobili
			for (int z = 0; z < immobili.size(); z = z + 1) {
				// La data presente nel vettore "cars" contenente unicamente le date della
				// pubblicazione delgli annunci
				// in maniera ordinata viene confrontata con quella presente all'interno del
				// vettore "immobili". Se viene trovata una
				// corrispondenza allora vengono stampate le altre informazioni relative
				// all'immobile in questione
				if (cars.get(i) == immobili.get(z).dataPubblicazione) {
					System.out.println("");
					System.out.println("");
					System.out.println("Annuncio n° " + z);
					System.out.print("Data di pubblicazione:  ");
					System.out.println(immobili.get(z).dataPubblicazione);
					System.out.print("Superficie:  ");
					System.out.print(immobili.get(z).superficie);
					System.out.println(" mq");
					System.out.print("Prezzo:  ");
					System.out.print(immobili.get(z).prezzo);
					System.out.println("€");
					System.out.print("Tipologia:  ");
					// Se si tratta di una villetta allora viene stampata anche questa informazione
					if (immobili.get(z).getClass().getName() == "immobili.Villetta") {
						System.out.println("Villetta");
						System.out.println("");
						// Altrimenti se si tratta di un appartamento allora viene stampata anche questa
						// informazione
					} else {
						System.out.println("Appartamento");
						System.out.println("");
					}
				}

			}

		}

	}

	// Consente di stampare gli immobili scegliendo la tipologia da visualizzare
	// (Appartamenti\Villette)
	public void VisualizzaPerTipo(int a) {
		String b;
		if (a == 1) {
			b = "immobili.Appartamento";
		} else {
			b = "immobili.Villetta";
		}
		for (int i = 0; i < immobili.size(); i = i + 1) {
			if (immobili.get(i).getClass().getName() == b) {
				System.out.println("");
				System.out.println("Annuncio n° " + i);
				System.out.print("Data di pubblicazione:  ");
				System.out.println(immobili.get(i).dataPubblicazione);
				System.out.print("Superficie:  ");
				System.out.print(immobili.get(i).superficie);
				System.out.println(" mq");
				System.out.print("Prezzo:  ");
				System.out.print(immobili.get(i).prezzo);
				System.out.println("€");
				System.out.print("Tipologia:  ");
				// Se si tratta di una villetta allora viene stampata anche questa informazione
				if (immobili.get(i).getClass().getName() == "immobili.Villetta") {
					System.out.println("Villetta");
					System.out.println("");
					// Altrimenti Se si tratta di un appartemento allora viene stampata anche questa
					// informazione
				} else {
					System.out.println("Appartamento");
					System.out.println("");
				}

			}
		}
	}

	// Consente di stampare gli immobili filtrandoli per estremi di prezzo
	public void VisualizzaPerPrezzo(int a, int b) {
		for (int i = 0; i < immobili.size(); i = i + 1) {
			if (immobili.get(i).prezzo >= a || immobili.get(i).prezzo <= b) {
				System.out.println("");
				System.out.println("Annuncio n° " + i);
				System.out.print("Data di pubblicazione:  ");
				System.out.println(immobili.get(i).dataPubblicazione);
				System.out.print("Superficie:  ");
				System.out.print(immobili.get(i).superficie);
				System.out.println(" mq");
				System.out.print("Prezzo:  ");
				System.out.print(immobili.get(i).prezzo);
				System.out.println("€");
				System.out.print("Tipologia:  ");
				if (immobili.get(i).getClass().getName() == "immobili.Villetta") {
					System.out.println("Villetta");
					System.out.println("");
				} else {
					System.out.println("Appartamento");
					System.out.println("");
				}
			}
		}
	}

	// Restituisce il numero di immobili
	public int contaNumeroImmobili() {
		int conto = 0;
		for (int i = 0; i < immobili.size(); i = i + 1) {
			conto = conto + 1;
		}
		return conto;

	}

	// salva il registro nel file restituisce true se il salvataggio è andato a buon
	// fine
	public boolean Salva() {
		try {
			ObjectOutputStream file_output = new ObjectOutputStream(
					new BufferedOutputStream(new FileOutputStream(nomefile)));
			// salva l'intero oggetto (vettore) nel file
			file_output.writeObject(immobili);
			file_output.close();
			return true;
		} catch (IOException e) {
			System.out.println("ERRORE di I/O");
			System.out.println(e);
			return false;
		}
	}

	// Carica il registro contenente gli annunci e lo importa, restituisce true se
	// il caricamento è andato a buon fine
	@SuppressWarnings("unchecked")
	public boolean Carica() {
		try {
			ObjectInputStream file_input = new ObjectInputStream(
					new BufferedInputStream(new FileInputStream(nomefile)));
			// legge l'intero vettore da file
			immobili = (Vector<Immobile>) file_input.readObject();
			file_input.close();
			return true;
		} catch (FileNotFoundException e) {
			// gestisce il caso in cui il file non sia presente (sara' creato poi...)
			System.out.println("ATTENZIONE: Il file " + nomefile + " non esiste");
			System.out.println("Sara' creato al primo salvataggio");
			System.out.println();
		} catch (ClassNotFoundException e) {
			// gestisce il caso in cui il file non contenga un oggetto
			System.out.println("ERRORE di lettura");
			System.out.println(e);
		} catch (IOException e) {
			// gestisce altri errori di input/output
			System.out.println("ERRORE di I/O");
			System.out.println(e);
		}
		return false;
	}

}
