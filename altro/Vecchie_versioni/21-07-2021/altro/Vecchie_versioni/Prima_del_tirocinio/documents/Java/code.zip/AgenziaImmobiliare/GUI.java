import immobili.Annunci;
import immobili.Appartamento;
import immobili.Immobile;
import immobili.Villetta;
import java.util.Scanner;
import java.util.InputMismatchException;
import javax.swing.*;
import java.awt.event.*;

public class GUI {

	// Metodo main
	public static void main(String[] args) {

		Annunci Annunci0 = new Annunci();// Creazione del contenitore dei vari immobili
		JLabel l1, l2;
		JButton b = new JButton("Esegui");
		final JLabel label = new JLabel();

		// INTRO
		JFrame f = new JFrame();
		l1 = new JLabel();
		l2 = new JLabel();
		l1.setBounds(50, 25, 600, 30);
		l2.setBounds(50, 45, 600, 30);
		b.setBounds(450, 90, 95, 20);
		f.add(l1);
		f.add(l2);

		f.add(b);
		l1.setText("Benvenuto nel programma di gestione degli annunci di un'agenzia immobiliare");

		// COMBO
		String scelte[] = { "Inserire annuncio", "Eliminare annuncio", "Visualizza per data",
				"Visualizza nel dettaglio", "Visualizza per tipologia", "Visualizza per estremi di prezzo", "Salva",
				"Carica" };
		JComboBox cb = new JComboBox(scelte);
		cb.setBounds(50, 90, 300, 20);
		f.add(cb);
		f.setLayout(null);

		f.setSize(700, 450);
		f.setLayout(null);
		f.setVisible(true);

		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = (String) cb.getSelectedItem();// get the selected item

				switch (s) {// check for a match
				case "Inserire annuncio":
					int doppi;
					int parcheggio;
					int riscaldamento;

					String dataPubb = JOptionPane.showInputDialog(f, "Inserire la data in formato aaaa-mm-gg");
					String citta = JOptionPane.showInputDialog(f, "inserire la citta'");
					String superficie = JOptionPane.showInputDialog(f, "inserire la superficie'");
					String anno = JOptionPane.showInputDialog(f, "inserire l'anno di costruzione");
					String classe = JOptionPane.showInputDialog(f, "inserire la classe energetica'");
					String stanze = JOptionPane.showInputDialog(f, "inserire il numero di stanze'");
					int a = JOptionPane.showConfirmDialog(f, "Sono presenti doppi sevizi?");
					if (a == JOptionPane.YES_OPTION) {
						doppi = 2;
					} else {
						doppi = 1;
					}
					String prezzo = JOptionPane.showInputDialog(f, "prezzo'");

					int b = JOptionPane.showConfirmDialog(f, "Premi SI per appartamento, NO per Villetta");
					if (b == JOptionPane.YES_OPTION) {
						String piano = JOptionPane.showInputDialog(f,
								"inserire il numero del piano in cui e' situato l'immobile'");
						String piani = JOptionPane.showInputDialog(f, "inserire il numero di piani del condominio'");
						int c = JOptionPane.showConfirmDialog(f, "E' presente un parcheggio?");
						if (c == JOptionPane.YES_OPTION) {
							parcheggio = 2;
						} else {
							parcheggio = 1;
						}
						int d = JOptionPane.showConfirmDialog(f, "E' presente il riscaldamento centralizzato?");
						if (d == JOptionPane.YES_OPTION) {
							riscaldamento = 2;
						} else {
							riscaldamento = 1;
						}
						Appartamento Immobile = new Appartamento(dataPubb, citta, Integer.parseInt(superficie),
								Integer.parseInt(anno), classe.charAt(0), Integer.parseInt(stanze), Trasforma12(doppi),
								Integer.parseInt(prezzo), Integer.parseInt(piano), Integer.parseInt(piani),
								Trasforma12(parcheggio), Trasforma12(riscaldamento));
						Annunci0.Inserisci(Immobile);

					} else {
						String giardino = JOptionPane.showInputDialog(f, "Indicare la dimensione del giardino");

						Villetta Immobile = new Villetta(dataPubb, citta, Integer.parseInt(superficie),
								Integer.parseInt(anno), classe.charAt(0), Integer.parseInt(stanze), Trasforma12(doppi),
								Integer.parseInt(prezzo), Integer.parseInt(giardino));
						Annunci0.Inserisci(Immobile);

					}

					// Scelta1(Annunci0);
					break;
				case "Eliminare annuncio":
					String Eliminato = JOptionPane.showInputDialog(f,
							"Inserire il numero di indice dell'annuncio che si desidera eliminare");
					int EliminatoInt = Integer.parseInt(Eliminato);
					Annunci0.Elimina(EliminatoInt);// Eliminazione attraverso l'utilizzo del metodo "Elimina" presente
													// in "Annunci"
					break;

				case "Visualizza per data":
//					f.add( new JScrollPane( textComponent ) );
//					MessageConsole mc = new MessageConsole(textComponent);
//					mc.redirectOut();
//					mc.redirectErr(Color.RED, null);
//					mc.setMessageLines(100);

					break;
				case "Visualizza nel dettaglio":
					break;
				case "Visualizza per tipologia":
					break;
				case "Visualizza per estremi di prezzo":
					break;
				case "Salva":
					Salva(Annunci0);
					break;
				case "Carica":
					Carica(Annunci0);
					break;

				}
			}
		});

	}






	// salva il registro nel file restituisce true se il salvataggio e' andato a
	// buon
	// fine
	private static void Salva(Annunci Annunci0) {

		boolean tuttoOk = Annunci0.Salva();// Utilizza il metodo "Salva" presente in "Annunci"
		if (tuttoOk)
			System.out.println("Dati salvati");
		else
			System.out.println("Problema durante il salvataggio");

	}

	private static void Carica(Annunci Annunci0) {

		boolean tuttoOk = Annunci0.Carica();// Utilizza il metodo "Salva" presente in "Annunci"
		if (tuttoOk)
			System.out.println("Dati caricati");
		else
			System.out.println("Problema durante il caricamento");

	}	
	

	private static boolean Trasforma12(int n) {
		boolean risp = false;
		if (n == 1) {
			risp = true;
		}
		return risp;

	}

	
	
	
	
	
}

