
//Importazione vari package 
import immobili.Annunci;
import immobili.Appartamento;
import immobili.Immobile;
import immobili.Villetta;
import java.util.Scanner;
import java.util.InputMismatchException;

public class GestioneAgenziaImmobiliare {

	// Metodo main
	public static void main(String[] args) {

		Annunci Annunci0 = new Annunci();// Creazione del contenitore dei vari immobili
		// Creazione di vari immobili per testare il programma (superflui)
//		Immobile Immobile0 = new Villetta("2015-09-20", " Lucca ", 300, 1969, 'A', 10, true, 50000, 700);
//		Villetta Immobile1 = new Villetta("2000-10-03", " Pisa ", 500, 2000, 'B', 20, false, 100000, 500);
//		Appartamento Immobile2 = new Appartamento("1969-09-21", " Firenze ", 200, 1980, 'C', 5, false, 30000, 3, 7,
//				true, true);
//		Appartamento Immobile3 = new Appartamento("1974-09-21", " Roma ", 300, 1950, 'D', 8, false, 70000, 8, 10, false,
//				true);

		// Gli immobili appena creati vengono inseriti in "Annunci"
//		Annunci0.Inserisci(Immobile0);
//		Annunci0.Inserisci(Immobile1);
//		Annunci0.Inserisci(Immobile2);
//		Annunci0.Inserisci(Immobile3);

		// Viene avviato il metodo che genera il messaggio iniziale, viene avviato
		// solamete quando si avvia il programma
		Avvio();

		// Ciclo senza fine per visualizzare il menu' principale dal quale è possibile
		// selezionare varie operazioni, esse sono descritte all'interno dei comandi di
		// stampa
		int scelta;
		do {
			System.out.println("");
			System.out.println("1 -- Inserimento nuovo annuncio");
			System.out.println("2 -- Eliminare un annuncio");
			System.out.println("3 -- Visualizzare l’elenco degli annunci in ordine di data in maniera sintetica");
			System.out.println("4 -- Visualizzare uno specifico annuncio in dettaglio");
			System.out.println(
					"5 -- Visualizzare l’elenco (sintetico) di tutti gli annunci di una tipologia a scelta tra appartamenti o villette  ");
			System.out.println(
					"6 -- Visualizzare l’elenco (sintetico) degli annunci il cui prezzo compreso tra un minimo e un massimo a scelta  ");
			System.out.println("7 -- Salvare l'elenco degli annunci");
			System.out.println("8 -- Caricare l'elenco degli annunci da un file");
			System.out.println("9 -- Terminare");

			scelta = Gestisci19(GestisciNumeri()); // Associo a questa variabile un input dell'utente

			// l'input del'utente viene identificato attraverso l'utilizzo del costrutto
			// "Switch". Per ogni scelta viene avviato un metodo specifico
			switch (scelta) {
			case 1:
				Scelta1(Annunci0);
				break;
			case 2:
				Scelta2(Annunci0);
				break;
			case 3:
				Scelta3(Annunci0);
				break;
			case 4:
				Scelta4(Annunci0);
				break;
			case 5:
				Scelta5(Annunci0);
				break;
			case 6:
				Scelta6(Annunci0);
				break;
			case 7:
				Salva(Annunci0);
				break;
			case 8:
				Carica(Annunci0);
				break;
			case 9:
				System.out.println("Terminato");
				System.exit(0);// Comando speciale per interrompere l'esecuione del programma
				break;

			}

		} while (scelta != 9);

	}

	// Genera il messaggio iniziale che si avvia una sola volta
	private static void Avvio() {

		System.out.println("");
		System.out.println("\tBenvenuto nel programma di gestione degli annunci di un'agenzia immobiliare");
		System.out.println("");
		System.out.println("");

		System.out.println("Ecco qui un elenco delle operazioni che e' possibile effettuare:");
		System.out.println("");

	}

	// Permette all'utente di inserire un nuovo annuncio relativo ad un immobile
	private static void Scelta1(Annunci Annunci0) {
		System.out.println(
				"Digiti il numero \"1\" se desidera inserire un Appartamento oppure \"2\" se desidera inserire una Villetta");
		int scelta2 = Gestisci12(GestisciNumeri()); // Associo a questa variabile un input dell'utente
		System.out.println("Inserire la data in formato aaaa-mm-gg");
		String scelta3 = GestisciDate(GestisciStringhe()); // Associo a questa variabile un input dell'utente
		System.out.println("Inserire la citta\'");
		String scelta4 = GestisciStringhe(); // Associo a questa variabile un input dell'utente
		System.out.println("Inserire la superficie in mq");
		int scelta5 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		System.out.println("Inserire l'anno di costruzione");
		int scelta6 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		System.out.println("Inserire la classe energetica espressa con un singolo carattere");
		char scelta7 = GestisciCaratteri();// Associo a questa variabile un input dell'utente
		System.out.println("Inserire il numero di stanze");
		int scelta8 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		System.out.println(
				"Indicare la presenza o meno di doppi servizi attraverso l'inserimento del numero \"1\" per rispondere affermativamente oppure con il numero \"2\" per rispondere negativamente");
		int scelta9 = Gestisci12(GestisciNumeri());// Associo a questa variabile un input dell'utente
		System.out.println("Inserire il prezzo dell'immobile");
		int scelta10 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		if (scelta2 == 1) {
			System.out.println("Inserire il numero del piano a cui e' situato l'immobile");
			int scelta11 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
			System.out.println("Inserire il numero di piani del palazzo in cui e' situato l'immobile");
			int scelta12 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
			System.out.println(
					"Indicare la presenza o meno di parcheggio attraverso l'inerimento del numero \"1\" per rispondere affermativamente oppure con il numero \"2\" per rispondere negativamente ");
			int scelta13 = Gestisci12(GestisciNumeri());// Associo a questa variabile un input dell'utente
			System.out.println(
					"Indicare la presenza o meno di riscaldamento autonomo attraverso l'inerimento del numero \"1\" per rispondere affermativamente oppure con il numero \"2\" per rispondere negativamente ");
			int scelta14 = Gestisci12(GestisciNumeri());// Associo a questa variabile un input dell'utente
			// Inserisco i dati ottenuti all'interno dell'oggetto
			Appartamento Immobile4 = new Appartamento(scelta3, scelta4, scelta5, scelta6, scelta7, scelta8,
					Trasforma12(scelta9), scelta10, scelta11, scelta12, Trasforma12(scelta13), Trasforma12(scelta14));
			Annunci0.Inserisci(Immobile4);
			System.out.println("Inserimento effettuato");
		}

		else {

			System.out.println("Inserire le dimensioni espresse in metri quadrati del giardino");
			int scelta11 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
			// Inserisco i dati ottenuti all'interno dell'oggetto
			Villetta Immobile = new Villetta(scelta3, scelta4, scelta5, scelta6, scelta7, scelta8, Trasforma12(scelta9),
					scelta10, scelta11);
			Annunci0.Inserisci(Immobile);
			System.out.println("Inserimento effettuato");

		}

	}

	// Trasforma i numeri "1" e "2" in valori booleani, questo e' necessario per
	// interpretare l'input dell'utente su determinate scelte
	private static boolean Trasforma12(int n) {
		boolean risp = false;
		if (n == 1) {
			risp = true;
		}
		return risp;

	}

	// Elimina un immmoblie presente in "Annunci" a partire dal suo indice
	public static void Scelta2(Annunci Annunci0) {

		System.out.println("Inserire il numero dell'immobile che si desidera eliminare");
		int scelta = GestisciVisualizzaElimina(GestisciNumeri(), Annunci0); // Associo a questa variabile un input
																			// dell'utente
		System.out.println("Vuoi procedere con l'eliminazione del seguente annuncio?");
		System.out.println("");
		Annunci0.VisualizzaScelto(scelta);
		System.out.println("");
		System.out.println(
				"Indicare la scelta attraverso l'inserimento del numero \"1\" per rispondere affermativamente oppure con il numero \"2\" per rispondere negativamente");
		// lettura dell'input dell'utente
		int scelta2 = Gestisci12(GestisciNumeri());
		if (Trasforma12(scelta2) == true) {
			Annunci0.Elimina(scelta);// Eliminazione attraverso l'utilizzo del metodo "Elimina" presente in "Annunci"
			System.out.println("Operazione effettuata");
		} else {
			System.out.println("Operazione annullata");
		}
	}

	// Viene invocato il metodo "VisualizzaPerData" presente in "Annunci" che
	// consente di visualizzare gli annunci di immobili ordinati per data
	private static void Scelta3(Annunci Annunci0) {
		Annunci0.VisualizzaPerData();
	}

	// Stampa un annuncio a partire dal suo numero di indice, questo deve essere
	// indicato dall'utente
	private static void Scelta4(Annunci Annunci0) {
		System.out.println("Inserire il numero dell'annuncio che si desidera consultare in dettaglio");
		int scelta = GestisciVisualizzaElimina(GestisciNumeri(), Annunci0); // Associo a questa variabile un input
																			// dell'utente
		Annunci0.VisualizzaScelto(scelta); // Utilizza il metodo "VisualizzaScelto" presente in "Annunci"
	}

	// Consente di stampare gli immobili scegliendo la tipologia da visualizzare
	// (Appartamenti\Villette)
	private static void Scelta5(Annunci Annunci0) {
		System.out.println(
				"Inserire il numero \"1\" per consultare gli immobili di tipologia Appartamento oppure \"2\" per consultare quelli di tipologia Villetta");
		int scelta = Gestisci12(GestisciNumeri()); // Associo a questa variabile un input dell'utente
		Annunci0.VisualizzaPerTipo(scelta); // Utilizza il metodo "VisualizzaPerTipo" presente in "Annunci"

	}

	// Consente di stampare gli immobili filtrandoli per estremi di prezzo indicati
	// dall'utente
	private static void Scelta6(Annunci Annunci0) {
		System.out.println(
				"Inserire gli estremi di prezzo per consultare gli annunci che vi rientrano partendo dal minore");
		int scelta1 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		int scelta2 = GestisciNumeri(); // Associo a questa variabile un input dell'utente
		Annunci0.VisualizzaPerPrezzo(scelta1, scelta2);// Utilizza il metodo "VisualizzaPerPrezzo" presente in "Annunci"

	}

	// salva il registro nel file restituisce true se il salvataggio e' andato a
	// buon
	// fine
	private static void Salva(Annunci Annunci0) {

		boolean tuttoOk = Annunci0.Salva();// Utilizza il metodo "Salva" presente in "Annunci"
		if (tuttoOk)
			System.out.println("Dati salvati");
		else
			System.out.println("Problema durante il salvataggio");

	}

	// Carica il registro contenente gli annunci e lo importa, restituisce true se
	// il caricamento e' andato a buon fine
	private static void Carica(Annunci Annunci0) {

		boolean tuttoOk = Annunci0.Carica();// Utilizza il metodo "Salva" presente in "Annunci"
		if (tuttoOk)
			System.out.println("Dati caricati");
		else
			System.out.println("Problema durante il caricamento");

	}

///Parte relativa alla gestione degli errori

//	Metodo per gestire le possibili eccezioni durante l'input da parte dell'utente di numeri
	private static int GestisciNumeri() {
		Scanner scanner = new Scanner(System.in);// inizializzo lo scanner che servira' a leggere l'input dell'utente
		int x = 0;
		boolean ok;
		do {
			ok = true;
			try {// viene eseguita una prova per verificare se l'input dell'utente genera o meno
					// errori
				x = scanner.nextInt();
			} catch (InputMismatchException e) {
				scanner.nextLine(); // annulla l’input ricevuto
				System.out.println(" Ritenta ...");
				ok = false;
			}
		} while (!ok);
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire le possibili eccezioni durante l'input da parte dell'utente di stringhe
	private static String GestisciStringhe() {
		Scanner scanner = new Scanner(System.in);// inizializzo lo scanner che servira' a leggere l'input dell'utente
		String x = "";
		boolean ok;
		do {
			ok = true;
			try {// viene eseguita una prova per verificare se l'input dell'utente genera o meno
					// errori
				x = scanner.nextLine();
			} catch (InputMismatchException e) {
				scanner.nextLine(); // annulla l’input ricevuto
				System.out.println(" Ritenta ...");
				ok = false;
			}
		} while (!ok);
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire le possibili eccezioni durante l'input da parte dell'utente di caratteri
	private static char GestisciCaratteri() {
		Scanner scanner = new Scanner(System.in);// inizializzo lo scanner che servira' a leggere l'input dell'utente
		char x = 'a';
		boolean ok;
		do {
			ok = true;
			try {// viene eseguita una prova per verificare se l'input dell'utente genera o meno
					// errori
				x = scanner.next().charAt(0);
			} catch (InputMismatchException e) {
				scanner.next().charAt(0); // annulla l’input ricevuto
				System.out.println(" Ritenta ...");
				ok = false;
			}
		} while (!ok);
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire il corretto inserimento dei valori "1" e "2" da parte del'utente
	private static int Gestisci12(int x) {
		// verifica che il numero sia diverso da "1" o "2"
		if (x < 1 || x > 2) {
			System.out.println(" Il numero deve essere o 1 o 2");
			// In questo caso il metodo si arresta restituendo l'invocazione dello stesso in
			// modo tale da far ripetere l'inserimento dell'input da parte dell'utente
			return (Gestisci12(GestisciNumeri()));
		}
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire il corretto inserimento dei valori  da "1" a "9" da parte del'utente
	private static int Gestisci19(int x) {
		// Viene verificato che il valore inserito sia compreso tra 1 e 9
		if (x < 1 || x > 9) {
			System.out.println(" Il numero deve essere compreso tra 0 e 10 esclusi");
			// In questo caso il metodo si arresta restituendo l'invocazione dello stesso in
			// modo tale da far ripetere l'inserimento dell'input da parte dell'utente
			return (Gestisci19(GestisciNumeri()));
		}
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire il corretto inserimento delle date da parte del'utente
	private static String GestisciDate(String x) {
//Viene verificata la correttezza del formato della data inserita dall'utente
		if (x.length() != 10 || x.charAt(4) != '-' || x.charAt(7) != '-') {
			System.out.println("La data deve comprendere gli zeri in posizione ");
			System.out.println("delle decine quando si indicano i mesi e i giorni");
			System.out.println("che non superano la singola cifra");
			// In questo caso il metodo si arresta restituendo l'invocazione dello stesso in
			// modo tale da far ripetere l'inserimento dell'input da parte dell'utente
			return (GestisciDate(GestisciStringhe()));
		}
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

//	Metodo per gestire il corretto inserimento dei valori numerici al fine di selezionare gli annunci da parte dell'utente
	private static int GestisciVisualizzaElimina(int x, Annunci Annunci0) {
		// Viene verificato il numero di immobili presenti attraverso l'opprtuno metodo
		// definito nella classe "Annunci"
		if (Annunci0.contaNumeroImmobili() <= x) {
			System.out.println("Annuncio non presente.");
			System.out.println("Indichi un numero minore");
			// In questo caso il metodo si arresta restituendo l'invocazione dello stesso in
			// modo tale da far ripetere l'inserimento dell'input da parte dell'utente
			return (GestisciVisualizzaElimina(GestisciNumeri(), Annunci0));
		}
		// Viene restituito il valore reso forzatamente corretto
		return x;
	}

}
