---
  layout: genres
  name: brazilian thrash metal
---