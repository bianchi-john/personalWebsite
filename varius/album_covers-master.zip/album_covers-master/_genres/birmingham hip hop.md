---
  layout: genres
  name: birmingham hip hop
---