---
  layout: genres
  name: afrobeat
---