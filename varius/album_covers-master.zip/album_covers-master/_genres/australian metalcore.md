---
  layout: genres
  name: australian metalcore
---