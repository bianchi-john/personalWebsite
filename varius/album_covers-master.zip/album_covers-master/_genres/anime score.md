---
  layout: genres
  name: anime score
---